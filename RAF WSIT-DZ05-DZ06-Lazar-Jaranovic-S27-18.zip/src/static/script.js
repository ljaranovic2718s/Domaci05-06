$(document).ready(function () {
    $("#labela").keyup(function () {
        var value = $("#labela");
        value = value.val().toLowerCase();
        $("#tabela tr").filter(function () {
            $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
        });
    });

    $("a").click(function (e) {
        var value = $(this)
        value = value.text().toLowerCase();
        $("#tabela tr").filter(function () {
            $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
        });
    });

});

